import React, { useEffect } from 'react';

const Google = () => {
  useEffect(() => {
    window.location.href = 'https://www.google.com';
  }, []);

  // Return null to prevent rendering anything in the component
  return null;
};

export default Google;
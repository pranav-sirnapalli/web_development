import React, { useState } from 'react';
import './PhoneGallery.css';

const images = [
  'https://cdn.firstcry.com/education/2022/11/26141737/Animal-Name-Starting-With-L-For-Kids.jpg',
  'https://www.goodnewsnetwork.org/wp-content/uploads/2022/10/red-panda-cub-first-vet-visit-Paradise-wildlife-park-in-Hertfordshire-SWNS.jpg',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQB1hhqsyGosZ3LGhgSOMa-OjCZtUCX2AbQscFq9emXdA&s',
];

export default function PhoneGallery() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const handleNext = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === images.length - 1 ? 0 : prevIndex + 1
    );
  };

  const handlePrev = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === 0 ? images.length - 1 : prevIndex - 1
    );
  };

  return (
    <div className="phone-gallery">
        <div className="image-container">
      <img
        className="image"
        src={images[currentImageIndex]}
        alt={`Image ${currentImageIndex + 1}`}
        style={{ maxWidth: '100%', maxHeight: '80vh' }}
      />
        <button className="arrow-button left-arrow" onClick={handlePrev}>&lt;</button>
        <button className="arrow-button right-arrow" onClick={handleNext}>&gt;</button>
      </div>
    </div>
  );
}
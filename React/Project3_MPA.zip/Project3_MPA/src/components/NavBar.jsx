import React from 'react';

export default function NavBar({ onLogout, onNavClick }) {
  return (
    <nav>
      <button onClick={() => onNavClick('calendar')}>Calendar</button>
      <button onClick={() => onNavClick('phoneGallery')}>PhoneGallery</button>
      <button onClick={() => onNavClick('calculator')}>Calculator</button>
      <button onClick={() => onNavClick('google')}>Google</button>
      <button onClick={onLogout}>Log out</button>
    </nav>
  );
}

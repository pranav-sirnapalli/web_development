import React, { useState } from 'react';

const Calculator = () => {
  const [result, setResult] = useState('');

  const handleClick = (value) => {
    if (value === '=') {
      try {
        setResult(eval(result).toString());
      } catch (error) {
        setResult('Error');
      }
    } else if (value === 'C') {
      setResult('');
    } else {
      setResult(result + value);
    }
  };

  return (
    <div style={{ padding: '20px', backgroundColor: '#f0f0f0', border: '1px solid #ccc', borderRadius: '5px' }}>
      <h2>Calculator</h2>
      <input
        type="text"
        value={result}
        style={{ width: '100%', marginBottom: '10px', padding: '5px' }}
        readOnly
      />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '5px' }}>
        {['7', '8', '9', '/'].map((item) => (
          <button key={item} onClick={() => handleClick(item)}>{item}</button>
        ))}
        {['4', '5', '6', '*'].map((item) => (
          <button key={item} onClick={() => handleClick(item)}>{item}</button>
        ))}
        {['1', '2', '3', '-'].map((item) => (
          <button key={item} onClick={() => handleClick(item)}>{item}</button>
        ))}
        {['C', '0', '=', '+'].map((item) => (
          <button key={item} onClick={() => handleClick(item)}>{item}</button>
        ))}
      </div>
    </div>
  );
};

export default Calculator;
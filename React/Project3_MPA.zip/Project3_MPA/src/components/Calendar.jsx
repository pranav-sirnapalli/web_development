import React, { useState } from 'react';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';

export default function MyCalendar() {
  const [date, setDate] = useState(new Date());

  const onChange = (date) => {
    setDate(date);
  };

  return (
    <div style={{ padding: '20px', backgroundColor: '#f0f0f0', border: '1px solid #ccc', borderRadius: '5px', display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
      <Calendar onChange={onChange} value={date} />
    </div>
  );
}


import React from 'react';

export default function Welcome() {
  return <div>
    <h1>Welcome to our website!</h1>
  </div>;
}

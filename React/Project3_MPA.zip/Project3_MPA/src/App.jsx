import React, { useState } from 'react';
import Welcome from './components/Welcome.jsx';
import Login from './components/Login.jsx';
import NavBar from './components/NavBar';
import Calendar from './components/Calendar.jsx';
import PhoneGallery from './components/PhoneGallery.jsx';
import Calculator from './components/Calculator';
import Google from './components/Google.jsx';
import Signup from './components/Signup.jsx';
//import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [selectedPage, setSelectedPage] = useState('');
  const [showSignup, setShowSignup] = useState(false);
  const [signupData, setSignupData] = useState(null);

  React.useEffect(() => {
    const data = localStorage.getItem('signupData');
    if(data){
      setSignupData(JSON.parse(data));
    }
  }, []);

  const handleLogin = (username, password) => {
    if(signupData && signupData.username === username && signupData.password === password){
     setLoggedIn(true);
    }
    else{
      alert('Invalid username or password');
    }
  };

  const handleLogout = () => {
    setLoggedIn(false);
  };

  const handleNavClick = (page) => {
    setSelectedPage(page);
  };

  const handleSignup = () => {
    setShowSignup(true);
  };

  const handleSignupClose = () => {
    setShowSignup(false);
  };

  const handleSignupSubmit = (data) => {
    localStorage.setItem('signupData', JSON.stringify(data));
    setSignupData(data);
    setShowSignup(false);
    setLoggedIn(false);
  };

  return (
    <div style={{}}>
      
      {!loggedIn && <Welcome />}
      {!loggedIn ? (
        <div style={{ display: 'flex', gap: '10px' }}>
          <Login onLogin={handleLogin} />
          <button onClick={handleSignup}>Signup</button>
          {showSignup && <Signup onClose={handleSignupClose} onSubmit={handleSignupSubmit} />}
        </div>
      ) : (
        <>
          <NavBar onLogout={handleLogout} onNavClick={handleNavClick} />
          {selectedPage === 'calendar' && <Calendar />}
          {selectedPage === 'phoneGallery' && <PhoneGallery />}
          {selectedPage === 'calculator' && <Calculator />}
          {selectedPage === 'google' && <Google />}
        </>
      )}
    </div>
  );
}
